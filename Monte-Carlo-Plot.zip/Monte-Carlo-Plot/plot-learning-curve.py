import matplotlib.pyplot as plt
import pickle
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
import matplotlib.patches as  mpatches
from sklearn.decomposition import PCA
import numpy as np
import os
# from matplotlib.pyplot import figure

kp = 'prediction_samples'
km = 'mc_samples'

plt.rcParams.update({'font.size': 11})
plt.rcParams.update({'figure.figsize': [6.4, 4.8]})

# plt.gcf().subplots_adjust(bottom=0.18)
# plt.gcf().subplots_adjust(top=0.95)
# plt.gcf().subplots_adjust(left=0.18)

def read(filename):
    with open(filename, 'rb') as file:
        obj = pickle.load(file)
    return obj

mmd_list = []
Q_pred, Q_fixed = [], []
for it in range(0, 19):
    for ep in range(0, 14000, 500):
        filename = f'evaluation_plots/iter-{it}/episode-{ep}.pickle'
        if not os.path.exists(filename):
            print("not exist:", filename)
            continue
        v0 = read(filename) 
        mmd_list.append(v0['mmd'])
        Q_pred.append(v0['prediction_samples'].mean())
        Q_fixed.append(v0['mc_samples'].mean())
        print(v0['mmd'], v0['mmd_scaled'])


plt.figure(figsize=(10, 4))
plt.subplot(121)
plt.plot(Q_pred, label='Q online', lw=2)
plt.plot(Q_fixed, label='Q fixed', lw=2)
plt.legend(fontsize=14)
plt.xlim([0, 500])
plt.xlabel("Epoch")
plt.ylabel("Q-value")
plt.grid()
# plt.suptitle("Maze 1")

plt.subplot(122)
plt.plot(mmd_list, label='W distance', lw=2)
plt.legend(fontsize=14)
plt.grid()
plt.xlim([0, 500])
plt.xlabel("Epoch")
# plt.suptitle("Maze 1")

plt.savefig("learning_curve_maze_3.pdf")
plt.show()

