import matplotlib.pyplot as plt
import pickle
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats
import matplotlib.patches as  mpatches
from sklearn.decomposition import PCA
import numpy as np
# from matplotlib.pyplot import figure

kp = 'prediction_samples'
km = 'mc_samples'

plt.rcParams.update({'font.size': 9})
plt.rcParams.update({'figure.figsize': [6.4, 4.8]})

def read(filename):
    with open(filename, 'rb') as file:
        obj = pickle.load(file)
    return obj
v0 = read('evaluation_plots/iter-17/episode-15500.pickle')   # pickle file in evaluation_plots for MultiRewardMaze-v0

legend_list = ['WGAN Prediction', 'Monte Carlo']
labels = ['orange', 'blue', 'green', 'red']
print(v0.keys(), v0['prediction_samples'].shape)


if True:
    np.set_printoptions(precision=3)
    print(v0['prediction_samples'].shape)
    print("Mean:", np.mean(v0['prediction_samples'], axis=0))
    print("Var:", np.var(v0['prediction_samples'], axis=0))
    print("quantile 0.1:", np.quantile(v0['prediction_samples'], 0.1, axis=0))
    print("quantile 0.3:", np.quantile(v0['prediction_samples'], 0.3, axis=0))
    print("quantile 0.5:", np.quantile(v0['prediction_samples'], 0.5, axis=0))
    print("quantile 0.7:", np.quantile(v0['prediction_samples'], 0.7, axis=0))
    print("quantile 0.9:", np.quantile(v0['prediction_samples'], 0.9, axis=0))


for i in range(4):
    for j in range(4):
        if i == j:
            continue

        name = labels[i]+"_"+labels[j]
        xlim, ylim = None, None
        if name in ["orange_blue", "orange_green", "orange_red"]:
            xlim = [-0.29, 0.49]
            if name == "orange_blue":
                ylim = [-0.5, 1.4]
            if name == "orange_green":
                ylim = [-0.3, 0.8]
            if name == "orange_red":
                ylim = [-0.4, 1.0]
        if name in ["blue_red", "blue_green"]:
            xlim = [-0.41, 1.3]
            if name == "blue_red":
                ylim = [-0.3, 1.0]
            if name == "blue_green":
                ylim = [-0.2, 0.8]

        # plt.figure(figsize=(10, 4))
        # ax = plt.gca()
        # ax.set_facecolor('whitesmoke')
        # ax.grid(linestyle='--', color='darkgray', linewidth=0.5, zorder=0)
        # ax.spines['top'].set_visible(False)
        # ax.spines['right'].set_visible(False)

        plt.figure(figsize=(10, 4))
        ax = plt.gca()
        ax.set_facecolor('whitesmoke')
        ax.grid(linestyle='--', color='darkgray', linewidth=0.5, zorder=0)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

        # prediction
        plt.subplot(121)
        sns.kdeplot(v0[kp][:, i], v0[kp][:, j], fill=True, bw=0.4, alpha=.9,
            color='blue', cmap="Blues", label=legend_list[0], legend=True, zorder=10)
        handles = [mpatches.Patch(facecolor=plt.cm.Blues(100), label=legend_list[0])]
        plt.legend(handles=handles, fontsize=14)
        if xlim:
            plt.xlim(xlim)
            plt.ylim(ylim)
        
        # monte carlo
        plt.subplot(122)
        sns.kdeplot(v0[km][:, i], v0[km][:, j], fill=True, bw=0.4, alpha=.9,
            color='red', cmap="Reds", label=legend_list[1], legend=True, zorder=10)
        handles = [mpatches.Patch(facecolor=plt.cm.Reds(100), label=legend_list[1])]
        plt.legend(handles=handles, fontsize=14)
        if xlim:
            plt.xlim(xlim)
            plt.ylim(ylim)

        plt.savefig("paper-plot/"+labels[i]+"_"+labels[j]+".pdf")
        plt.clf()

