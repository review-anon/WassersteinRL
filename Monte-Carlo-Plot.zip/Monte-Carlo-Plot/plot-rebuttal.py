from scipy import stats
from numpy.random import seed
from numpy.random import randn
from numpy.random import lognormal
import numpy as np
import pickle
from scipy.stats import ks_2samp, kstest


kp = 'prediction_samples'
km = 'mc_samples'

def read(filename):
    with open(filename, 'rb') as file:
        obj = pickle.load(file)
    return obj
v0 = read('evaluation_plots/iter-17/episode-15500.pickle')   # pickle file in evaluation_plots for MultiRewardMaze-v0

labels = ['orange', 'blue', 'green', 'red']


for i in range(4):
    for j in range(4):
        if i == j:
            continue

        name = labels[i]+"_"+labels[j]

        data1 = v0[kp][:, i]   # prediction
        data2 = v0[km][:, i]   # monte carlo
        print("data:", data1.shape, data2.shape)

        res = ks_2samp(data1, data2)
        # res = stats.kstest(data1, data2)
        print("ks test:", res)


